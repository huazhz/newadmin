# controlOrder
`controlOrder` allows you to define a new order for the elements in the control bar.

## Usage
```javascript
var options = {
      controlOrder: [
        'text',
        'textarea'
      ]
    };
$(container).formBuilder(options);
```


## See it in Action
<p data-height="494" data-theme-id="22927" data-slug-hash="rezdaa" data-default-tab="result" data-embed-version="2" data-user="kevinchappell" class="codepen">See the Pen <a href="http://codepen.io/kevinchappell/pen/rezdaa"></p>

