# editOnAdd
When the option `editOnAdd` is set to true, fields will automatically enter edit mode when added to the stage.

## Usage
```javascript
var options = {
      editOnAdd: true
    };
$(container).formBuilder(options);
```

## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="grXkNg" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
